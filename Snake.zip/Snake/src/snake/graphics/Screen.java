/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snake.graphics;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;
import objects.Body;
import objects.Dot;

/**
 *
 * @author Nick
 */
public class Screen extends JPanel implements Runnable{
    public static final int WIDTH = 800, HEIGHT = 800;
    private Thread thread;
    private boolean running = false;
    private Body b;
    private ArrayList<Body> snake;
    private ArrayList<Body> snake2;
    private int XCorr, YCorr, XCorr2, YCorr2; 
    private int size=4, size2 = 4;
    private int tileSize = 20;
    private boolean right =false,left = false,up=false,down=true;
    private boolean right2 =false,left2 = false,up2=false,down2 = true;
    private int ticks;
    private int maxTicks = 2500000;
    private Key key;
    private Dot dot, dot2;
    private JLabel j;
    public boolean gameStart=false;
    
    public Screen()
    {
        XCorr = (WIDTH/tileSize)/2 + 5;
        YCorr = (HEIGHT/tileSize)/2;
        XCorr2 = (WIDTH/tileSize)/2 - 5;
        YCorr2 = (HEIGHT/tileSize)/2;
        setFocusable(true);
        key= new Key();
        addKeyListener(key);
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        snake = new ArrayList<Body>();
        snake2 = new ArrayList<Body>();
        
        dot = new Dot(1, 1, tileSize, WIDTH, HEIGHT);
        dot2 = new Dot(1, 1, tileSize, WIDTH, HEIGHT);
        dot.changePos(snake, snake2, dot2);
        dot2.changePos(snake, snake2, dot);
        
        
        
        start();
    }
    public void tick()
    {
        //System.out.println(ticks);
        if(snake.size() == 0)
        {
            b=new Body(XCorr,YCorr, tileSize, 1);
            snake.add(b);
        }
        if(snake2.size() == 0)
        {
            b=new Body(XCorr2,YCorr2, tileSize, 2);
            snake2.add(b);
        }
        ticks++;
        
        if(ticks>maxTicks)
        {
            //System.out.println(right);
            maxTicks -= 1500;
            System.out.println(maxTicks);
           // System.out.println(up);
            //System.out.println(down);
            
            if(right)XCorr++;
            if(left)XCorr--;
            //System.out.println( XCorr +" "+ YCorr);
            if(up)YCorr--;
            if(down)YCorr++;
            if(right2)XCorr2++;
            if(left2)XCorr2--;
            if(up2)YCorr2--;
            if(down2)YCorr2++;
            
            ticks = 0;
            
            b=new Body(XCorr,YCorr,tileSize, 1);
            snake.add(b);
            
            b=new Body(XCorr2,YCorr2,tileSize, 2);
            snake2.add(b);
            
            int temp = hitDot(snake);
            if (temp != 0)
            {
                size++;
                if (temp == 1){
                    dot.changePos(snake, snake2, dot);
                }
                else if (temp == 2){
                    dot2.changePos(snake, snake2, dot);
                }
                
            }
            
            temp = hitDot(snake2);
            if (temp != 0)
            {
                size2++;
                if (temp == 1){
                    dot.changePos(snake, snake2, dot);
                }
                else if (temp == 2){
                    dot2.changePos(snake, snake2, dot);
                }
                
            }
            temp = loseGame();
            if (temp != 0)
            {
                stop();
            }
        
            if(snake.size()>size)
            {
               snake.remove(0);
            }
            
            if(snake2.size()>size2)
            {
                snake2.remove(0);
            }
        }

    }
    
    public int hitDot(ArrayList<Body> snek) //0 none, 1 = dot1, 2= dot2
    {
        int headX = snek.get(snek.size()-1).getXCorr();
        int headY = snek.get(snek.size()-1).getYCorr();
        if (dot.getXCorr() == headX && dot.getYCorr() == headY)
        {
            return 1;
        }
        else if (dot2.getXCorr() == headX && dot2.getYCorr() == headY)
        {
            return 2;
        }
        return 0;
    }
    
    public int loseGame() //0 = false, 1 = snake1 lose, 2 = snake2, 3 = both lose (aka a tie)
    {
        int headX = snake.get(snake.size()-1).getXCorr();
        int headY = snake.get(snake.size()-1).getYCorr();
        
        for (int i=0;i<snake.size()-1;i++)
        {
            if (snake.get(i).getXCorr() == headX && snake.get(i).getYCorr() == headY)
            {
                return 1;
            }
            if (snake.get(i).getXCorr() >= WIDTH/tileSize || snake.get(i).getXCorr() <= 0)
            {
                return 1;
            }
            else if (snake.get(i).getYCorr() >= HEIGHT/tileSize || snake.get(i).getYCorr() <= 0)
            {
                return 1;
            }
        }
        
        headX = snake2.get(snake2.size()-1).getXCorr();
        headY = snake2.get(snake2.size()-1).getYCorr();
        
        for (int i=0;i<snake2.size()-1;i++)
        {
            if (snake2.get(i).getXCorr() == headX && snake2.get(i).getYCorr() == headY)
            {
                return 2;
            }
            if (snake2.get(i).getXCorr() >= WIDTH/tileSize || snake2.get(i).getXCorr() <= 0)
            {
                return 2;
            }
            else if (snake2.get(i).getYCorr() >= HEIGHT/tileSize || snake2.get(i).getYCorr() <= 0)
            {
                return 2;
            }
        }
        
        return hitOther();
    }
    
    public int hitOther() //0 = nothing, 1 = snake1 lose, 2 = snake2 lose, 3 = tie
    {
        int headX = snake.get(snake.size()-1).getXCorr();
        int headY = snake.get(snake.size()-1).getYCorr();
        int headX2 = snake2.get(snake2.size()-1).getXCorr();
        int headY2 = snake2.get(snake2.size()-1).getYCorr();
        if (headX == headX2 && headY == headY2)
        {
            return 3;
        }
        for (int i = 0; i < snake2.size() - 1; i++)
        {
            if (snake2.get(i).getXCorr() == headX && snake2.get(i).getYCorr() == headY)
            {
                return 1;
            }
        }
        for (int i = 0; i < snake.size() - 1; i++)
        {
            if (snake.get(i).getXCorr() == headX2 && snake.get(i).getYCorr() == headY2)
            {
                return 2;
            }
        }
        return 0;
    }
    
    public void paint(Graphics g)
    {
        
        g.clearRect(0, 0, WIDTH, HEIGHT);
        g.setColor(Color.black);
        g.fillRect(0, 0, WIDTH, HEIGHT);
         
        
        if(gameStart)
        {
            for(int i=0;i<WIDTH/tileSize;i++)
            {
                g.drawLine(i*tileSize, 0, i*tileSize, HEIGHT);
            }
            for(int i=0;i<HEIGHT/tileSize;i++){
                g.drawLine(0,i*tileSize,WIDTH,i*tileSize);
            }
            for(int i=0;i<snake.size();i++)
            {
                snake.get(i).draw(g);
            }

            for(int i=0;i<snake2.size();i++)
            {
                snake2.get(i).draw(g);
            }

            dot.draw(g);
            dot2.draw(g);
            int temp = loseGame();
            Font font = new Font("Verdana", Font.BOLD, 64);
            g.setFont(font);
            if (temp == 1){
                g.setColor(Color.LIGHT_GRAY);
                g.drawString("Player 1 Wins", WIDTH/2-250, HEIGHT/2);

            }
            else if (temp == 2){
                g.setColor(Color.LIGHT_GRAY);
                g.drawString("Player 2 Wins", WIDTH/2-250, HEIGHT/2);

            }
            else if (temp == 3){
                g.setColor(Color.LIGHT_GRAY);
                g.drawString("It's a tie", WIDTH/2-160, HEIGHT/2);

            }
        }
        else
        {
            Font font = new Font("Verdana", Font.BOLD, 32);
            g.setFont(font);
            g.setColor(Color.LIGHT_GRAY);
         g.drawString("Press any key to start", WIDTH/2-160, HEIGHT/2);
        }
        
    }
    
    public void start()
    {
        running = true;
        thread = new Thread(this, "Game Loop");
        thread.start();
    }
    public void stop()
    {
        running = false;
        //thread.stop();
        
    }
    public void run()
    {
        
        
            while(running)
            {
                if(gameStart)
                {
                    tick();
                }
                repaint();
            }
            
        
        
        
    
    }

    private class Key implements KeyListener {
    
        @Override
        public void keyPressed(KeyEvent e) 
        {
            int key = e.getKeyCode();
            if(gameStart)
            {
        
                if (key == e.VK_RIGHT && !left) 
                {
                    up = false;
                    down = false;
                    right = true;
                }

                if (key == e.VK_LEFT && !right) 
                {
                    up = false;
                    down = false;
                    left = true;
                }

                if (key == e.VK_UP && !down) 
                {
                    left = false;
                    right = false;
                    up = true;
                }

                if (key == e.VK_DOWN && !up) 
                {
                    left = false;
                    right = false;
                    down = true;
                }

                if (key == e.VK_D && !left2) 
                {
                    up2 = false;
                    down2 = false;
                    right2 = true;
                }

                if (key == e.VK_A && !right2) 
                {
                    up2 = false;
                    down2 = false;
                    left2 = true;
                }

                if (key == e.VK_W && !down2) 
                {
                    left2 = false;
                    right2 = false;
                    up2 = true;
                }

                if (key == e.VK_S && !up2) 
                {
                    left2 = false;
                    right2 = false;
                    down2 = true;
                }
            }
            else
            {
                gameStart =true;
            }
            
            
        }
    
    
        @Override
        public void keyTyped(KeyEvent arg0)
        {
        
        }

        @Override
        public void keyReleased(KeyEvent e) 
        {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }
}



