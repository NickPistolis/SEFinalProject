/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objects;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Nick
 */
public class Body {
    private int XCorr,YCorr,width,height, player;
    public Body(int XCorr, int YCorr, int tileSize, int player)
    {
        this.player = player;
        this.XCorr=XCorr;
        this.YCorr=YCorr;
        width = tileSize;
        height = tileSize;
    }
    public void tick()
    {
        
    }
    public void draw(Graphics g)
    {
        g.setColor(Color.BLACK);
        g.fillRect(XCorr*width, YCorr*height, width, height);
        if (player == 1)
        {
            g.setColor(Color.BLUE);
        }
        else if (player == 2)
        {
            g.setColor(Color.RED);
        }
        g.fillRect(XCorr*width +1, YCorr*height+1, width-3, height-3 );
        
    }
    
    public int getXCorr()
    {
        return this.XCorr;
    }
    
    public int getYCorr()
    {
        return this.YCorr;
    }
    
}
