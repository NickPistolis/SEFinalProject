/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objects;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Nick
 */
public class Dot{

    private int XCorr;
    private int YCorr;
    private int tileSize;
    private int WIDTH;
    private int HEIGHT;
    
    public Dot(int XCorr, int YCorr, int tileSize, int width, int height)
    {
        this.XCorr = XCorr;
        this.YCorr = YCorr;
        this.tileSize = tileSize;
        WIDTH = width;
        HEIGHT = height;
    }
    
    public void changePos(ArrayList<Body> snake, ArrayList<Body> snake2, Dot dot){
        Random rand = new Random();
        this.XCorr = rand.nextInt(WIDTH/tileSize/2) + 1;
        this.YCorr = rand.nextInt(HEIGHT/tileSize/2) + 1;
        for (int i = 0; i < snake.size(); i++)
        {
            if (snake.get(i).getXCorr() == this.XCorr && snake.get(i).getYCorr() == this.YCorr)
            {
                changePos(snake, snake2, dot);
                System.out.println(XCorr + "" + YCorr);
            }
        }
        for (int i = 0; i < snake2.size(); i++)
        {
            if (snake2.get(i).getXCorr() == this.XCorr && snake2.get(i).getYCorr() == this.YCorr)
            {
                changePos(snake, snake2, dot);
            }
        }
//        if (dot.getXCorr() == XCorr && dot.getYCorr() == YCorr){
//            changePos(snake, snake2, dot);
//        }
    }
    
    public void draw(Graphics g)
    {
        g.setColor(Color.WHITE);
        g.fillRect(XCorr*tileSize, YCorr*tileSize+2, tileSize-4, tileSize-4 );
    }
    
    public int getXCorr()
    {
        return this.XCorr;
    }
    
    public int getYCorr()
    {
        return this.YCorr;
    }
}

